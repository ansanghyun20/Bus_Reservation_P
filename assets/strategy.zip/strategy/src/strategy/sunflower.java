package strategy;

public class sunflower extends Flower_Plant {
	public sunflower() {
		cotyledons_N = new Two_Cotyledons();
		root_N = new Straight_Root();
	}
	public void display() {
		System.out.println("�عٶ�� �Դϴ�.");
	}

}

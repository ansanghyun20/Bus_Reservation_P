package strategy;

public class dandelion extends Flower_Plant {
	public dandelion() {
		cotyledons_N = new Two_Cotyledons();
		root_N = new Straight_Root();
	}
	public void display() {
		System.out.println("�ε鷹 �Դϴ�.");
	}

}

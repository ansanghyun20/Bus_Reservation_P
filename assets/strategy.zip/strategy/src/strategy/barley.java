package strategy;

public class barley extends Flower_Plant{
	public barley() {
		cotyledons_N = new One_Cotyledons();
		root_N = new Beard_Root();
	}
	public void display() {
		System.out.println("�����Դϴ�.");
	}

}

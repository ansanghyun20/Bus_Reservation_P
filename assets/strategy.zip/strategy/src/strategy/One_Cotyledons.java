package strategy;

public class One_Cotyledons implements CotyledonsN {
	@Override
	public void cotyledons() {
		System.out.println("�ܶ��� �Ĺ��Դϴ�.");
	}

}

package strategy;

public class Main {
	public static void main(String[] args) {
		barley b = new barley();
		b.display();
		b.performCotyledons();
		b.performRoot();
		b.bloom();
		
		System.out.println();
		sunflower s = new sunflower();
		s.display();
		s.performCotyledons();
		s.performRoot();
		s.bloom();
		s.setCotyledons(new Minus_CotyledonsN());
		s.performCotyledons();
	}
}

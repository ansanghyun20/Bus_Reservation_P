package strategy;

public interface RootN {
	public void root();
}

package strategy;

public class greenFoxtail extends Flower_Plant {
	public greenFoxtail() {
		cotyledons_N = new One_Cotyledons();
		root_N = new Beard_Root();
	}
	public void display() {
		System.out.println("������ Ǯ �Դϴ�.");
	}
}

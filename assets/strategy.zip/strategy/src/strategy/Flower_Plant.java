package strategy;

public abstract class Flower_Plant {
	CotyledonsN cotyledons_N;
	RootN root_N;
	
	public Flower_Plant() {
		
	}
	
	public void performCotyledons() {
		cotyledons_N.cotyledons();
	}
 
	public void performRoot() {
		root_N.root();
	}
	
	public abstract void display();
		
	public void bloom() {
		System.out.println("��ȭ �մϴ�.");
	}
	
	
	public void setCotyledons(CotyledonsN cy) {
		cotyledons_N = cy;
	}
 
	public void setRoot(RootN rt) {
		root_N = rt;
	}
	
}



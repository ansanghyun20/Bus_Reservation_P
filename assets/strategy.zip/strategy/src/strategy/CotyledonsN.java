package strategy;

public interface CotyledonsN {
	public void cotyledons();
}

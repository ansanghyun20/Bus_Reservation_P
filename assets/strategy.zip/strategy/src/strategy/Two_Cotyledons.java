package strategy;

public class Two_Cotyledons implements CotyledonsN {
	@Override
	public void cotyledons() {
		System.out.println("�ֶ��� �Ĺ��Դϴ�.");
	}

}
